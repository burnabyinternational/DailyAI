
require('dotenv').config();
const express = require('express');
const line = require('@line/bot-sdk');
const axios = require('axios');

const config = {
  channelAccessToken: process.env.LINE_ACCESS_TOKEN,
  channelSecret: process.env.LINE_CHANNEL_SECRET
};

const client = new line.Client(config);
const app = express();

app.post('/webhook', line.middleware(config), (req, res) => {
  res.status(200).send('OK'); // Immediate response to LINE

  req.body.events.forEach(async (event) => {
    if (event.type === 'message' && event.message.type === 'text') {
      const userMessage = event.message.text;
      const replyText = await getAIResponse(userMessage);
      try {
        await client.replyMessage(event.replyToken, {
          type: 'text',
          text: replyText
        });
      } catch (err) {
        console.error('LINE reply error:', err.message);
      }
    }
  });
});

async function getAIResponse(inputText) {
  const prompt = `You are Daily Sun AI, a friendly English tutor for CEFR A1 elementary students in Asia.
Correct the user's sentence, explain in simple English, and give a short example.

Sentence: "${inputText}"`;

  try {
    const response = await axios.post('https://api.openai.com/v1/chat/completions', {
      model: 'gpt-3.5-turbo',
      messages: [{ role: 'user', content: prompt }],
      temperature: 0.7
    }, {
      headers: {
        'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`,
        'Content-Type': 'application/json'
      }
    });

    return response.data.choices[0].message.content.trim();
  } catch (error) {
    console.error('OpenAI error:', error.response?.data || error.message);
    return "Sorry, I'm having trouble helping right now.";
  }
}

app.get('/', (req, res) => {
  res.send('☀️ Daily Sun AI is running!');
});

const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`App running on port ${port}`);
});
